<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.00
    </div>
    <strong>&copy; {{ date('Y') }} <a href="/">{{ $setting->nama_perusahaan }}</a>.</strong> All rights
    reserved.
</footer>